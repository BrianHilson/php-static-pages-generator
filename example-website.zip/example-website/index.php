<?php


require_once($_SERVER['DOCUMENT_ROOT'] . '/static-pages-generator/static-pages-generator.php');

$blogGen = new StaticPagesGenerator();
$blogGen->SetBlogDir('/harry-potter-blog');
$blogGen->SetMarkdownFileDir('/static-pages-generator/markdown-files');
$blogGen->SetTemplateFilepath('/static-pages-generator/static-page-template.php');
$blogGen->SetBlogPostsDataFilepath('/static-pages-generator/all-blog-data.json');
$blogGen->GenerateBlogs();

if(isset($_GET['refresh']))
{
  $blogGen->UpdateAllBlogPosts();
}

$blogData = $blogGen->GetCurrentBlogPostData();
$blogData = $blogGen->ExcludeHiddenPosts($blogData);
$blogData = $blogGen->SortBlogDataByDate($blogData, 'DESC');

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Index page</title>
</head>
<body>
<?php include($_SERVER['DOCUMENT_ROOT'] . '/includes/header.php'); ?>
<main>
  <section class="articles">
<?php
  foreach($blogData as $post) {
?>
    <article>
      <div class="description">
        <h2><a href="<?php echo $post['metaData']['link']; ?>"><?php echo $post['metaData']['title']; ?></a></h2>
        <h3><?php echo date('M j, Y', strtotime($post['metaData']['publishDate'])) . ' &middot; ' . $post['metaData']['minutesToRead'] . ' min. read'; ?></h3>
        <p><?php echo $post['metaData']['description']; ?></p>
      </div>
    </article>
<?php
}
?>

  </section>
</main>
<?php include($_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'); ?>
</body>
</html>