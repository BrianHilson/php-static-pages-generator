<footer>
  <p>Some footer elements</p>
</footer>