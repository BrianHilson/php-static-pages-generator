<header>
  <nav>Some navigation elements</nav>
</header>