---
title: Top Ten Most Popular Spells At Hogwarts
description: Jinxes, hexes, and curses you want to know
publishDate: January 25 2020
---
Lorem, ipsum dolor sit amet consectetur adipisicing elit. Hic laborum non maiores quidem eius velit esse debitis eligendi tempore ad dignissimos iste quam rem quae, unde, numquam impedit? Ex, itaque?

Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere mollitia reprehenderit error illo ipsum doloremque non, quidem inventore placeat harum libero unde aperiam cum dolorem recusandae dolorum totam, maxime quas?