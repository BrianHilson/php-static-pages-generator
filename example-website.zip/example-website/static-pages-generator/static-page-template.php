<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="description" content="<?php echo $blogPostData['metaData']['description']; ?>">
  <title><?php echo $blogPostData['metaData']['title']; ?></title>
</head>
<body>
<?php include($_SERVER['DOCUMENT_ROOT'] . '/includes/header.php'); ?>
<main>
  <article class="content">
    <h1><?php echo $blogPostData['metaData']['title']; ?></h1>
    <h3>
<?php 
    if (!$blogPostData['metaData']['noDate']) {
      echo date('M j, Y', strtotime($blogPostData['metaData']['publish_date'])); 
    }

    if ($blogPostData['metaData']['minutesToRead']) { 
      echo' &middot; ' . $blogPostData['metaData']['minutesToRead'] . ' min. read';
    }
?>
    </h3>
    <?php echo $blogPostData['body']; ?>
  </article>
  </main>
<?php include($_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'); ?>
</body>
</html>